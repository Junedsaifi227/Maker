<?php

// Display the Settings page
function wp_management_settings() {
    if (!wp_management_is_api_key_valid()) {
        echo '<div class="notice notice-error"><p>API key is not valid. Please set a valid API key in the API Key section.</p></div>';
        return;
    }

    // Handle form submission
    if (isset($_POST['save_settings'])) {
        $delete_on_deactivation = isset($_POST['delete_on_deactivation']) ? 1 : 0;
        update_option('wp_management_delete_on_deactivation', $delete_on_deactivation);
        echo '<div class="notice notice-success"><p>Settings saved successfully.</p></div>';
    }

    // Get the current settings
    $delete_on_deactivation = get_option('wp_management_delete_on_deactivation', 0);

    // Display the form
    echo '<h1>Settings</h1>';
    echo '<form method="post">';
    echo '<p>';
    echo '<label for="delete_on_deactivation">';
    echo '<input type="checkbox" id="delete_on_deactivation" name="delete_on_deactivation" value="1"' . checked(1, $delete_on_deactivation, false) . '>';
    echo ' Delete all duplicated items when the plugin is deactivated';
    echo '</label>';
    echo '</p>';
    echo '<p>';
    echo '<button type="submit" name="save_settings" class="button button-primary">Save Settings</button>';
    echo '</p>';
    echo '</form>';
}
?>