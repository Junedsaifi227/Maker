<?php

// Display the Theme Options page
function wp_management_theme_options() {
    if (isset($_POST['set_theme'])) {
        $theme = sanitize_text_field($_POST['theme']);
        update_option('wp_management_theme', $theme);
        echo '<div class="notice notice-success"><p>Theme set successfully.</p></div>';
    }

    // Get the current theme
    $current_theme = get_option('wp_management_theme', 'light');

    // Display the form
    echo '<h1>Theme Options</h1>';
    echo '<form method="post">';
    echo '<p>';
    echo '<label for="theme">Select Theme:</label><br>';
    echo '<select id="theme" name="theme">';
    echo '<option value="light"' . selected($current_theme, 'light', false) . '>Light</option>';
    echo '<option value="dark"' . selected($current_theme, 'dark', false) . '>Dark</option>';
    echo '</select>';
    echo '</p>';
    echo '<p>';
    echo '<button type="submit" name="set_theme" class="button button-primary">Set Theme</button>';
    echo '</p>';
    echo '</form>';
}

// Apply the selected theme
function wp_management_apply_theme() {
    $theme = get_option('wp_management_theme', 'light');
    if ($theme === 'dark') {
        echo '<style>
            body {
                background-color: #333;
                color: #fff;
            }
            .wrap h1, .wrap h2, .wrap p {
                color: #fff;
            }
            .wp-list-table {
                color: #fff;
            }
            .button, .button-primary, .button-secondary {
                background-color: #444;
                border-color: #444;
                color: #fff;
            }
            .button:hover, .button-primary:hover, .button-secondary:hover {
                background-color: #555;
                border-color: #555;
                color: #fff;
            }
        </style>';
    }
}
add_action('admin_head', 'wp_management_apply_theme');
?>