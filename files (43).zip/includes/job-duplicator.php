<?php

// Display the Job Duplicator page
function wp_management_job_duplicator() {
    if (!wp_management_is_api_key_valid()) {
        echo '<div class="notice notice-error"><p>API key is not valid. Please set a valid API key in the API Key section.</p></div>';
        return;
    }

    // Get all job listings
    $jobs = get_posts(array(
        'post_type' => 'job_listing',
        'posts_per_page' => -1
    ));

    // Get all companies (assuming companies are stored as a custom post type)
    $companies = get_posts(array(
        'post_type' => 'company',
        'posts_per_page' => -1
    ));

    // Handle form submission
    if (isset($_POST['duplicate_jobs'])) {
        $job_id = intval($_POST['job_id']);
        $company_id = intval($_POST['company_id']);
        $locations = explode(',', sanitize_text_field($_POST['locations']));

        // Validate and sanitize locations
        $locations = array_map('trim', $locations);
        $locations = array_filter($locations);

        // Initialize or get the duplicated jobs data
        $duplicated_jobs = get_option('wp_management_duplicated_jobs', array());

        // Duplicate the job for each location
        foreach ($locations as $location) {
            $location = strtolower($location);
            // Fetch the original job post
            $job_post = get_post($job_id);
            if ($job_post && $job_post->post_type === 'job_listing') {
                // Create a new job post
                $new_post = array(
                    'post_title' => $job_post->post_title . ' - ' . $location,
                    'post_content' => $job_post->post_content,
                    'post_status' => 'publish',
                    'post_type' => 'job_listing',
                    'post_author' => $job_post->post_author,
                );

                // Insert the new post into the database
                $new_post_id = wp_insert_post($new_post);

                // Copy meta data from the original post
                $meta_keys = get_post_meta($job_id);
                foreach ($meta_keys as $key => $values) {
                    foreach ($values as $value) {
                        add_post_meta($new_post_id, $key, $value);
                    }
                }

                // Update the location meta field
                update_post_meta($new_post_id, '_job_location', $location);

                // Update the company meta field if a new company is selected
                if ($company_id) {
                    update_post_meta($new_post_id, '_company_id', $company_id);
                }

                // Copy taxonomy terms (job tags, job categories, job types)
                $taxonomies = get_object_taxonomies('job_listing');
                foreach ($taxonomies as $taxonomy) {
                    $terms = wp_get_post_terms($job_id, $taxonomy, array('fields' => 'ids'));
                    wp_set_object_terms($new_post_id, $terms, $taxonomy);
                }

                // Update the duplicated jobs data
                if (isset($duplicated_jobs[$location])) {
                    $duplicated_jobs[$location]['count']++;
                    $duplicated_jobs[$location]['companies'][] = get_the_title($company_id);
                    $duplicated_jobs[$location]['post_ids'][] = $new_post_id;
                } else {
                    $duplicated_jobs[$location] = array(
                        'count' => 1,
                        'companies' => array(get_the_title($company_id)),
                        'post_ids' => array($new_post_id)
                    );
                }
            }
        }

        // Save the duplicated jobs data
        update_option('wp_management_duplicated_jobs', $duplicated_jobs);

        echo '<div class="notice notice-success"><p>Jobs duplicated successfully.</p></div>';
    }

    // Display the form
    echo '<h1>Job Duplicator</h1>';
    echo '<form method="post">';
    echo '<p>';
    echo '<label for="job_id">Select Job from WP Job Manager:</label><br>';
    echo '<select id="job_id" name="job_id" required>';
    foreach ($jobs as $job) {
        echo '<option value="' . $job->ID . '">' . $job->post_title . '</option>';
    }
    echo '</select>';
    echo '</p>';
    echo '<p>';
    echo '<label for="company_id">Select Company from MAS Companies For WP Job Manager:</label><br>';
    echo '<select id="company_id" name="company_id">';
    echo '<option value="">Keep original company</option>';
    foreach ($companies as $company) {
        echo '<option value="' . $company->ID . '">' . $company->post_title . '</option>';
    }
    echo '</select>';
    echo '</p>';
    echo '<p>';
    echo '<label for="locations">Enter the list of locations separated by commas:</label><br>';
    echo '<input type="text" id="locations" name="locations" required>';
    echo '</p>';
    echo '<p>';
    echo '<button type="submit" name="duplicate_jobs">Duplicate Jobs</button>';
    echo '</p>';
    echo '</form>';
}
?>