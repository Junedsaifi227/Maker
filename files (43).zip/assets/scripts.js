jQuery(document).ready(function($) {
    // Apply the initial theme
    if (wp_management.currentTheme === 'dark') {
        $('body').addClass('dark-theme');
        $('#theme-selector').val('dark');
    } else {
        $('#theme-selector').val('light');
    }

    // Theme selector change
    $('#theme-selector').on('change', function() {
        if ($(this).val() === 'dark') {
            $('body').addClass('dark-theme');
            updateThemeOption('dark');
        } else {
            $('body').removeClass('dark-theme');
            updateThemeOption('light');
        }
    });

    // Update theme option in the database
    function updateThemeOption(theme) {
        $.post(wp_management.ajaxUrl, {
            action: 'wp_management_update_theme',
            theme: theme
        });
    }

    // View companies modal
    $('.view-companies').on('click', function(e) {
        e.preventDefault();
        let location = $(this).data('location');
        $('#modal-location').text(location);

        // Fetch companies for the location
        let companies = wp_management_duplicated_jobs[location]['companies'];
        let companyList = $('#company-list');
        companyList.empty();
        companies.forEach(function(company) {
            companyList.append('<li>' + company + '</li>');
        });

        $('#company-modal').show();
    });

    // Close modal
    $('#company-modal-close').on('click', function() {
        $('#company-modal').hide();
    });
});