<?php

// Display the Job Fetcher page
function wp_management_job_fetcher() {
    if (!wp_management_is_api_key_valid()) {
        echo '<div class="notice notice-error"><p>API key is not valid. Please set a valid API key in the API Key section.</p></div>';
        return;
    }

    // Handle form submission
    if (isset($_POST['fetch_jobs'])) {
        $website_url = sanitize_text_field($_POST['website_url']);
        $response = wp_remote_get($website_url);

        if (is_wp_error($response)) {
            echo '<div class="notice notice-error"><p>Failed to fetch jobs. Please check the website URL.</p></div>';
        } else {
            $html = wp_remote_retrieve_body($response);

            // Use DOMDocument to parse HTML
            $dom = new DOMDocument();
            libxml_use_internal_errors(true);
            $dom->loadHTML($html);
            libxml_clear_errors();

            // Extract job listings from HTML (this part needs to be customized based on the structure of the external website)
            $job_elements = $dom->getElementsByTagName('job'); // Placeholder for actual job element tags

            foreach ($job_elements as $job_element) {
                // Extract job details
                $title = $job_element->getElementsByTagName('title')->item(0)->nodeValue;
                $description = $job_element->getElementsByTagName('description')->item(0)->nodeValue;
                $location = $job_element->getElementsByTagName('location')->item(0)->nodeValue;
                $company_id = $job_element->getElementsByTagName('company_id')->item(0)->nodeValue;

                // Create a new job post
                $new_post = array(
                    'post_title' => sanitize_text_field($title),
                    'post_content' => wp_kses_post($description),
                    'post_status' => 'publish',
                    'post_type' => 'job_listing',
                );

                // Insert the new post into the database
                $new_post_id = wp_insert_post($new_post);

                // Add job meta data
                update_post_meta($new_post_id, '_job_location', sanitize_text_field($location));
                update_post_meta($new_post_id, '_company_id', intval($company_id));
            }

            echo '<div class="notice notice-success"><p>Jobs fetched and created successfully.</p></div>';
        }
    }

    // Display the form
    echo '<h1>Job Fetcher</h1>';
    echo '<form method="post">';
    echo '<p>';
    echo '<label for="website_url">Enter Website URL to fetch jobs:</label><br>';
    echo '<input type="text" id="website_url" name="website_url" required>';
    echo '</p>';
    echo '<p>';
    echo '<button type="submit" name="fetch_jobs">Fetch Jobs</button>';
    echo '</p>';
    echo '</form>';
}
?>