<?php

// Add the plugin menu to the admin sidebar
function wp_management_menu() {
    add_menu_page('Dashboard', 'Dashboard', 'manage_options', 'wp-management', 'wp_management_dashboard', 'dashicons-admin-generic');
    add_submenu_page('wp-management', 'Job Duplicator', 'Job Duplicator', 'manage_options', 'job-duplicator', 'wp_management_job_duplicator');
    add_submenu_page('wp-management', 'API Key', 'API Key', 'manage_options', 'api-key', 'wp_management_api_key');
    add_submenu_page('wp-management', 'Settings', 'Settings', 'manage_options', 'settings', 'wp_management_settings');
}

add_action('admin_menu', 'wp_management_menu');

// Check if the API key is valid
function wp_management_is_api_key_valid() {
    $stored_api_key = get_option('wp_management_api_key');
    return $stored_api_key === WP_MANAGEMENT_API_KEY;
}
?>