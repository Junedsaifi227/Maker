<?php
/*
Plugin Name: Dashboard
Plugin URI: https://example.com/
Description: A plugin to duplicate and publish job posts, manage API keys, and other settings.
Version: 1.2
Author: J Tech
Author URI: https://example.com/
*/

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define constants
define('WP_MANAGEMENT_API_KEY', 'Jobduplicator@123467890');
define('WP_MANAGEMENT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WP_MANAGEMENT_PLUGIN_URL', plugin_dir_url(__FILE__));

// Include necessary files
include_once WP_MANAGEMENT_PLUGIN_DIR . 'includes/admin-menu.php';
include_once WP_MANAGEMENT_PLUGIN_DIR . 'includes/job-duplicator.php';
include_once WP_MANAGEMENT_PLUGIN_DIR . 'includes/api-key.php';
include_once WP_MANAGEMENT_PLUGIN_DIR . 'includes/settings.php';
include_once WP_MANAGEMENT_PLUGIN_DIR . 'includes/dashboard.php';
include_once WP_MANAGEMENT_PLUGIN_DIR . 'includes/theme-options.php';

// Enqueue scripts and styles
function wp_management_enqueue_scripts($hook) {
    wp_enqueue_style('wp-management-styles', WP_MANAGEMENT_PLUGIN_URL . 'assets/styles.css');
    wp_enqueue_script('wp-management-scripts', WP_MANAGEMENT_PLUGIN_URL . 'assets/scripts.js', array('jquery'), null, true);

    // Pass theme information to the script
    $current_theme = get_option('wp_management_theme', 'light');
    wp_localize_script('wp-management-scripts', 'wp_management', array(
        'currentTheme' => $current_theme,
        'ajaxUrl' => admin_url('admin-ajax.php')
    ));
}
add_action('admin_enqueue_scripts', 'wp_management_enqueue_scripts');

// Hook for plugin deactivation
register_deactivation_hook(__FILE__, 'wp_management_deactivate');
function wp_management_deactivate() {
    if (get_option('wp_management_delete_on_deactivation')) {
        global $wpdb;
        $duplicated_jobs = get_option('wp_management_duplicated_jobs', array());
        foreach ($duplicated_jobs as $data) {
            foreach ($data['post_ids'] as $post_id) {
                wp_delete_post($post_id, true);
            }
        }
        delete_option('wp_management_duplicated_jobs');
    }
}
?>