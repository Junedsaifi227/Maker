<?php

// Display the dashboard page
function wp_management_dashboard() {
    if (isset($_POST['clear_data'])) {
        // Clear duplicated job data
        delete_option('wp_management_duplicated_jobs');
        echo '<div class="notice notice-success"><p>Duplicated job data cleared successfully.</p></div>';
    }

    echo '<div style="display: flex; justify-content: space-between; align-items: center;">';
    echo '<h1 style="font-size: 2em;">Dashboard</h1>';
    echo '<button id="theme-toggler" class="button">';
    echo '<span id="theme-icon" class="dashicons dashicons-sun"></span> <span id="theme-text">Light</span>';
    echo '</button>';
    echo '</div>';
    echo '<p>Welcome to the Dashboard plugin.</p>';

    // Fetch the duplicated job data
    $duplicated_jobs = get_option('wp_management_duplicated_jobs', array());

    if (!empty($duplicated_jobs)) {
        echo '<h2 style="font-size: 1.5em;">Duplicated Jobs</h2>';
        echo '<table class="wp-list-table widefat fixed striped dashboard-table">';
        echo '<thead><tr><th style="font-size: 1.2em;">Location</th><th style="font-size: 1.2em;">Number of Jobs</th></tr></thead>';
        echo '<tbody>';
        foreach ($duplicated_jobs as $location => $data) {
            echo '<tr>';
            echo '<td><a href="#" class="view-companies" data-location="' . esc_attr($location) . '">' . esc_html($location) . '</a></td>';
            echo '<td><a href="#" class="view-companies" data-location="' . esc_attr($location) . '">' . esc_html($data['count']) . '</a></td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
    } else {
        echo '<p>No jobs have been duplicated yet.</p>';
    }

    echo '<form method="post">';
    echo '<p>';
    echo '<button type="submit" name="clear_data" class="button button-secondary">Clear Data</button>';
    echo '</p>';
    echo '</form>';

    // Modal for viewing companies
    echo '<div id="company-modal" class="hidden">';
    echo '<div id="company-modal-content">';
    echo '<span id="company-modal-close">&times;</span>';
    echo '<h2>Companies for <span id="modal-location"></span></h2>';
    echo '<ul id="company-list"></ul>';
    echo '</div>';
    echo '</div>';
}
?>