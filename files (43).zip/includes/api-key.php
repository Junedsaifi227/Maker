<?php

// Display the API Key page
function wp_management_api_key() {
    // Handle form submission
    if (isset($_POST['set_api_key'])) {
        $api_key = sanitize_text_field($_POST['api_key']);
        update_option('wp_management_api_key', $api_key);
        echo '<div class="notice notice-success"><p>API key set successfully.</p></div>';
    }

    // Get the current API key
    $current_api_key = get_option('wp_management_api_key', '');

    // Display the form
    echo '<h1>API Key</h1>';
    echo '<form method="post">';
    echo '<p>';
    echo '<label for="api_key">Enter API Key:</label><br>';
    echo '<input type="text" id="api_key" name="api_key" required>';
    echo '</p>';
    echo '<p>';
    echo '<button type="submit" name="set_api_key" class="button button-primary">Set API Key</button>';
    echo '</p>';
    echo '</form>';

    // Display the current API key with dots
    if (!empty($current_api_key)) {
        $masked_api_key = str_repeat('*', strlen($current_api_key));
        echo '<p>Current API Key: <span>' . $masked_api_key . '</span></p>';
    }
}
?>